import re
import os


def get_all_exercises():
    with open('all_exercises.txt', 'r') as r:
        lines = r.read().split('\n')
        if len(lines) % 2 == 1:
            print('err : icons and exercises mismatch!')
        else:
            return [(lines[2*i+1], lines[2*i]) for i in range(0, int(len(lines)/2))]


def get_exercises(filename):
    res = set()
    with open(filename, 'r') as r:
        for line in r:
            r = re.search(r'(exerciseitem__name)(--long)?">([\w\s-]+)(<\/span>)', line)
            if r:
                res.add(r.group(3))
    return res


def get_body_parts():
    return {x[:x.rindex('.')]:None for x in os.listdir('./body parts') if x.endswith('.html')}


def get_categories():
    return {x[:x.rindex('.')]:None for x in os.listdir('./categories') if x.endswith('.html')}


if __name__ == '__main__':
    all_exercises = get_all_exercises()
    body_parts = get_body_parts()
    categories = get_categories()

    for body_part in body_parts:
        body_parts[body_part] = get_exercises(f'./body parts/{body_part}.html')
    for category in categories:
        categories[category] = get_exercises(f'./categories/{category}.html')
    
    with open('exercises.csv', 'w+') as w:
        w.write('exercise, icon, body part, category\n')
        all_exercises = list(all_exercises)
        all_exercises.sort(key=lambda x: x[0])
        for exercise, icon in all_exercises:
            _body_parts = []
            for body_part in body_parts:
                if exercise in body_parts[body_part]:
                    _body_parts += [body_part]
            _categories = []
            for category in categories:
                if exercise in categories[category]:
                    _categories += [category]
            w.write(f'{exercise},{icon},{"/".join(_body_parts)},{"/".join(_categories)}\n')
